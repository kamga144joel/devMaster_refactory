const serverless = require('serverless-http');
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Clés API intégrées
const OPENAI_API_KEY = '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';
const GEMINI_API_KEY = 'AIzaSyBZRdYr5Lge7Tjf6-mns-HlX319uQaxfyc';

// Mentor handler
app.post('/mentor', async (req, res) => {
  try {
    const { question, code, language } = req.body;
    
    if (!question) {
      return res.status(400).json({ error: 'question required' });
    }

    // Mock response pour mentor IA
    const mockResponse = {
      advice: `Pour votre question "${question}", voici mes conseils :
1. Analysez bien le problème
2. Décomposez-le en petites étapes
3. Testez chaque partie séparément
4. N'hésitez pas à demander de l'aide !`,
      suggestions: [
        "Revoyez les bases du langage",
        "Pratiquez avec des exercices simples",
        "Utilisez la documentation officielle"
      ]
    };

    res.json(mockResponse);
  } catch (e) {
    res.status(500).json({ error: 'mentor_failed', message: String(e?.message || e) });
  }
});

module.exports.handler = serverless(app);
