const serverless = require('serverless-http');
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// MailJet send handler
app.post('/send-mailjet', async (req, res) => {
  try {
    const { to, subject, text, html } = req.body;
    
    if (!to || !subject) {
      return res.status(400).json({ error: 'to and subject required' });
    }

    // Mock response - envoi email via MailJet
    const mockResponse = {
      ok: true,
      message: 'Email envoyé via MailJet',
      to: to,
      subject: subject,
      sent_at: new Date().toISOString(),
      message_id: `mock_${Date.now()}`
    };

    res.json(mockResponse);
  } catch (e) {
    res.status(500).json({ error: 'mailjet_failed', message: String(e?.message || e) });
  }
});

module.exports.handler = serverless(app);
