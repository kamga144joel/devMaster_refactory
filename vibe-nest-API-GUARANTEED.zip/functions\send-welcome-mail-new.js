const serverless = require('serverless-http');
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Clés API MailJet intégrées
const MJ_APIKEY_PUBLIC = 'e162678819818aac742356c0b675b568';
const MJ_APIKEY_PRIVATE = 'd546dbc29649d21dd7f24e155e434add';
const MJ_FROM_EMAIL = 'kamgathierry@cinaf.tv';

// Email handler
app.post('/send-welcome-mail', async (req, res) => {
  try {
    const { email, name } = req.body;
    if (!email) return res.status(400).json({ error: 'missing_email' });

    if (!MJ_APIKEY_PUBLIC || !MJ_APIKEY_PRIVATE) {
      return res.status(500).json({ error: 'missing_mailjet_keys' });
    }

    const payload = {
      Messages: [
        {
          From: { Email: MJ_FROM_EMAIL, Name: 'DevMaster' },
          To: [{ Email: email, Name: String((name || (email || '').split('@')[0] || '')) }],
          Subject: 'Bienvenue sur DevMaster 🎉',
          TextPart: `Bienvenue sur DevMaster! Merci de vous être inscrit.`,
          HTMLPart: `<!doctype html><html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/></head><body><h1>Bienvenue ${String((name || (email || '').split('@')[0] || ''))}</h1><p>Merci de vous être inscrit sur DevMaster.</p></body></html>`,
          CustomID: 'DevMasterWelcome'
        }
      ]
    };

    const auth = Buffer.from(`${MJ_APIKEY_PUBLIC}:${MJ_APIKEY_PRIVATE}`).toString('base64');
    const resp = await fetch('https://api.mailjet.com/v3.1/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Basic ${auth}`
      },
      body: JSON.stringify(payload)
    });

    const text = await resp.text();
    if (!resp.ok) return res.status(502).json({ error: 'mailjet_error', detail: text });

    return res.json({ ok: true, detail: text });
  } catch (e) {
    return res.status(500).json({ error: 'exception', message: String(e?.message || e) });
  }
});

module.exports.handler = serverless(app);
