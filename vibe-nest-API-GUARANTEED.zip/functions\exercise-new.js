const serverless = require('serverless-http');
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Exercise handler
app.post('/exercise', async (req, res) => {
  try {
    const { language, difficulty, topic } = req.body;
    
    // Mock response - génération d'exercices
    const mockExercise = {
      id: 1,
      title: `Exercice ${language} - ${topic || 'Variables'}`,
      description: `Pratiquez les concepts de base en ${language}`,
      difficulty: difficulty || 'facile',
      instructions: `Écrivez un programme qui...`,
      solution: `// Solution\nconst result = "exemple";`,
      hints: [
        "Pensez à la syntaxe de base",
        "Utilisez les bonnes pratiques"
      ],
      created_at: new Date().toISOString()
    };

    res.json(mockExercise);
  } catch (e) {
    res.status(500).json({ error: 'exercise_failed', message: String(e?.message || e) });
  }
});

module.exports.handler = serverless(app);
