const serverless = require('serverless-http');
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Clés API intégrées
const OPENAI_API_KEY = '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';
const GEMINI_API_KEY = 'AIzaSyBZRdYr5Lge7Tjf6-mns-HlX319uQaxfyc';

// Chat handler
app.post('/chat', async (req, res) => {
  try {
    const { messages, message } = req.body;
    const messageArray = Array.isArray(messages) ? messages : (message ? [{ role: 'user', content: String(message) }] : []);
    
    if (!messageArray.length) {
      return res.status(400).json({ error: 'messages required' });
    }

    const userMessage = messageArray.map(m => `${m.role}: ${m.content}`).join('\n');
    
    // Mock response pour l'instant
    const mockResponse = {
      reply: "Bonjour ! Je suis votre assistant IA. Comment puis-je vous aider aujourd'hui ?"
    };

    res.json(mockResponse);
  } catch (e) {
    res.status(500).json({ error: 'chat_failed', message: String(e?.message || e) });
  }
});

module.exports.handler = serverless(app);
