const serverless = require('serverless-http');
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Spotify handler
app.get('/spotify', async (req, res) => {
  try {
    const { type, query } = req.query;
    
    // Mock response - données Spotify
    const mockSpotify = {
      type: type || 'tracks',
      data: [
        {
          id: 1,
          name: "Coding Music",
          artist: "Dev Beats",
          album: "Programming Vibes",
          preview_url: "https://example.com/preview.mp3"
        },
        {
          id: 2,
          name: "Focus Flow",
          artist: "Code Composer",
          album: "Developer Sessions",
          preview_url: "https://example.com/preview2.mp3"
        }
      ],
      total: 2
    };

    res.json(mockSpotify);
  } catch (e) {
    res.status(500).json({ error: 'spotify_failed', message: String(e?.message || e) });
  }
});

module.exports.handler = serverless(app);
