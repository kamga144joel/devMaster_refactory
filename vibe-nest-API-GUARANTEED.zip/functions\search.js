const serverless = require('serverless-http');
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Search handler
app.get('/search', async (req, res) => {
  try {
    const { q, type, limit = 10 } = req.query;
    
    // Mock response - recherche
    const mockSearch = {
      query: q || '',
      results: [
        {
          id: 1,
          title: "Introduction à JavaScript",
          type: "course",
          description: "Apprenez les bases de JavaScript",
          url: "/course/javascript-intro"
        },
        {
          id: 2,
          title: "Variables et Types",
          type: "exercise",
          description: "Exercice sur les variables",
          url: "/exercise/variables"
        }
      ],
      total: 2,
      took: 5
    };

    res.json(mockSearch);
  } catch (e) {
    res.status(500).json({ error: 'search_failed', message: String(e?.message || e) });
  }
});

module.exports.handler = serverless(app);
