const serverless = require('serverless-http');
const express = require('express');
const cors = require('cors');
const path = require('path');

// Import your server routes
const { createServer } = require('../../dist/server/node-build.mjs');

const app = express();

// Enable CORS
app.use(cors());
app.use(express.json());

// Mount API routes
const server = createServer();
app.use('/api', server);

// Export as serverless function
module.exports.handler = serverless(app);
