const serverless = require('serverless-http');
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Clés API intégrées
const HUGGINGFACE_API_KEY = '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';
const OPENAI_API_KEY = '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';

// Glossaire IA handler
app.post('/glossary-ai', async (req, res) => {
  try {
    const { term, context } = req.body;
    
    if (!term) {
      return res.status(400).json({ error: 'term required' });
    }

    // Mock response pour glossaire IA
    const mockResponse = {
      term: term,
      definition: `Définition de "${term}" : concept fondamental en programmation`,
      explanation: `Ce terme est utilisé pour décrire ${context || 'divers concepts techniques'}`,
      examples: [
        `Exemple 1 avec ${term}`,
        `Exemple 2 illustrant ${term}`
      ],
      related: [
        'Concept connexe 1',
        'Concept connexe 2'
      ]
    };

    res.json(mockResponse);
  } catch (e) {
    res.status(500).json({ error: 'glossary_failed', message: String(e?.message || e) });
  }
});

module.exports.handler = serverless(app);
