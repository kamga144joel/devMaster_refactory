const serverless = require('serverless-http');
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Image generation handler
app.post('/image', async (req, res) => {
  try {
    const { prompt, style, size } = req.body;
    
    if (!prompt) {
      return res.status(400).json({ error: 'prompt required' });
    }

    // Mock response - génération d'images
    const mockImage = {
      url: `https://picsum.photos/seed/${encodeURIComponent(prompt)}/512/512.jpg`,
      prompt: prompt,
      style: style || 'realistic',
      size: size || '512x512',
      created_at: new Date().toISOString(),
      model: 'mock-image-generator'
    };

    res.json(mockImage);
  } catch (e) {
    res.status(500).json({ error: 'image_failed', message: String(e?.message || e) });
  }
});

module.exports.handler = serverless(app);
