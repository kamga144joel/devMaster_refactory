const serverless = require('serverless-http');
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Export handler
app.post('/export', async (req, res) => {
  try {
    const { type, data, format } = req.body;
    
    // Mock response - export de données
    const mockExport = {
      ok: true,
      type: type || 'json',
      format: format || 'download',
      url: `https://example.com/export/${Date.now()}.${format || 'json'}`,
      size: 1024,
      created_at: new Date().toISOString()
    };

    res.json(mockExport);
  } catch (e) {
    res.status(500).json({ error: 'export_failed', message: String(e?.message || e) });
  }
});

module.exports.handler = serverless(app);
