const serverless = require('serverless-http');
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Course handler
app.post('/course', async (req, res) => {
  try {
    const { language, framework, topic } = req.body;
    
    // Mock response - génération de cours
    const mockCourse = {
      title: `Cours ${language} - ${topic || 'Introduction'}`,
      modules: [
        {
          id: 1,
          title: "Introduction",
          content: `Bienvenue dans ce cours ${language}...`,
          exercises: 3
        },
        {
          id: 2,
          title: "Concepts de base",
          content: `Apprenez les fondamentaux de ${language}...`,
          exercises: 5
        }
      ],
      created_at: new Date().toISOString()
    };

    res.json(mockCourse);
  } catch (e) {
    res.status(500).json({ error: 'course_failed', message: String(e?.message || e) });
  }
});

module.exports.handler = serverless(app);
