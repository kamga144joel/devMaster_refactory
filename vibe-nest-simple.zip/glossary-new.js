const serverless = require('serverless-http');
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Glossary handler
app.get('/glossary', async (req, res) => {
  try {
    const { search, letter } = req.query;
    
    // Mock response - glossaire de termes
    const mockGlossary = {
      terms: [
        {
          term: "API",
          definition: "Interface de Programmation Applicative",
          category: "Développement",
          examples: ["REST API", "GraphQL"]
        },
        {
          term: "Variable",
          definition: "Conteneur pour stocker des données",
          category: "Programmation",
          examples: ["let x = 5", "const name = 'test'"]
        }
      ],
      total: 2,
      filtered: search ? 1 : 2
    };

    res.json(mockGlossary);
  } catch (e) {
    res.status(500).json({ error: 'glossary_failed', message: String(e?.message || e) });
  }
});

module.exports.handler = serverless(app);
