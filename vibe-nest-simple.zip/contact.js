const serverless = require('serverless-http');
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Contact handler
app.post('/contact', async (req, res) => {
  try {
    const { name, email, message } = req.body;
    
    if (!email || !message) {
      return res.status(400).json({ error: 'email and message required' });
    }

    // Mock response - envoie d'email de contact
    const mockResponse = {
      ok: true,
      message: 'Message envoyé avec succès',
      sent_at: new Date().toISOString()
    };

    res.json(mockResponse);
  } catch (e) {
    res.status(500).json({ error: 'contact_failed', message: String(e?.message || e) });
  }
});

module.exports.handler = serverless(app);
