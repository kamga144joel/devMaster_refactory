const serverless = require('serverless-http');
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Welcome list handler
app.get('/welcome-list', async (req, res) => {
  try {
    // Mock data pour la liste des emails de bienvenue
    const mockWelcomeList = [
      {
        name: 'Alice',
        email: 'alice@example.com',
        sent_at: new Date().toISOString()
      },
      {
        name: 'Bob',
        email: 'bob@example.com',
        sent_at: new Date(Date.now() - 86400000).toISOString()
      }
    ];

    res.json({ ok: true, data: mockWelcomeList, source: 'local_mock' });
  } catch (e) {
    res.status(500).json({ error: 'exception', message: String(e?.message || e) });
  }
});

module.exports.handler = serverless(app);
