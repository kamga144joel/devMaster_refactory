const serverless = require('serverless-http');
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Genius handler
app.post('/genius', async (req, res) => {
  try {
    const { query, context } = req.body;
    
    // Mock response - IA Genius pour réponses avancées
    const mockGenius = {
      answer: `Réponse Genius pour: "${query}"`,
      confidence: 0.95,
      sources: [
        "Documentation officielle",
        "Best practices",
        "Stack Overflow"
      ],
      explanation: "Voici une explication détaillée...",
      examples: [
        "Exemple 1",
        "Exemple 2"
      ],
      created_at: new Date().toISOString()
    };

    res.json(mockGenius);
  } catch (e) {
    res.status(500).json({ error: 'genius_failed', message: String(e?.message || e) });
  }
});

module.exports.handler = serverless(app);
