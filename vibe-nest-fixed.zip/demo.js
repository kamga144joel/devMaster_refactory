const serverless = require('serverless-http');
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Demo handler
app.get('/demo', async (req, res) => {
  try {
    const mockDemo = {
      message: "Demo API fonctionne !",
      features: [
        "Quiz IA",
        "Chat IA", 
        "Mentor IA",
        "Glossaire IA",
        "Exercices interactifs"
      ],
      timestamp: new Date().toISOString()
    };

    res.json(mockDemo);
  } catch (e) {
    res.status(500).json({ error: 'demo_failed', message: String(e?.message || e) });
  }
});

module.exports.handler = serverless(app);
