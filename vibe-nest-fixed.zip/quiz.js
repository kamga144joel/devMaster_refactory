const serverless = require('serverless-http');
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Clés API intégrées
const OPENAI_API_KEY = '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';
const GEMINI_API_KEY = 'AIzaSyBZRdYr5Lge7Tjf6-mns-HlX319uQaxfyc';

// Quiz handler inline pour éviter les imports ES modules
app.post('/quiz', async (req, res) => {
  try {
    if (!OPENAI_API_KEY && !GEMINI_API_KEY) {
      return res.status(502).json({ 
        error: "IA services unavailable", 
        message: "Les APIs IA ne sont pas disponibles." 
      });
    }

    // Simulation de génération de quiz
    const mockQuiz = {
      questions: [
        {
          id: 1,
          q: "Quelle est la différence entre let et const en JavaScript ?",
          options: ["let peut être réassignée", "const est plus rapide", "let est globale", "const est obsolète"],
          correct: 0,
          explain: "let permet la réassignation de la variable, tandis que const crée une référence constante."
        },
        {
          id: 2,
          q: "Qu'est-ce qu'une closure en JavaScript ?",
          options: ["Une boucle", "Une fonction avec accès aux variables externes", "Un objet", "Un tableau"],
          correct: 1,
          explain: "Une closure est une fonction qui a accès aux variables de sa portée parente même après que la parente soit terminée."
        }
      ]
    };

    res.json(mockQuiz);
  } catch (e) {
    res.status(500).json({ error: "quiz_failed", message: String(e?.message || e) });
  }
});

module.exports.handler = serverless(app);
