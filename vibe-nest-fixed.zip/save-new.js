const serverless = require('serverless-http');
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Save handler
app.post('/save', async (req, res) => {
  try {
    const { namespace = 'default', key, data, userId } = req.body;
    
    if (!key || typeof data === 'undefined') {
      return res.status(400).json({ error: 'key and data required' });
    }

    // Mock response - sauvegarde locale
    const mockSave = {
      ok: true,
      namespace,
      key,
      userId: userId || 'anonymous',
      saved_at: new Date().toISOString(),
      size: JSON.stringify(data).length
    };

    res.json(mockSave);
  } catch (e) {
    res.status(500).json({ error: 'save_failed', message: String(e?.message || e) });
  }
});

module.exports.handler = serverless(app);
